package com.example.amar.testapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    public static EditText et_num1, et_num2;
    public static Button bt_add;
    public static TextView tv_result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void add(View view){
        et_num1 = (EditText)findViewById(R.id.etNum1);
        et_num2 = (EditText)findViewById(R.id.etNum2);
      //  et_result = (EditText)findViewById(R.id.etResult);
        tv_result = (TextView)findViewById(R.id.tvResult);

        int num1 = Integer.parseInt(et_num1.getText().toString());
        int num2 = Integer.parseInt(et_num2.getText().toString());
        int result = num1 + num2;

       // et_result.setText(Integer.toString(result));
        tv_result.setText(Integer.toString(result));

    }

    public void sub(View view){

        et_num1=(EditText)findViewById(R.id.etNum1);
        et_num2=(EditText)findViewById(R.id.etNum2);
        tv_result=(TextView)findViewById(R.id.tvResult);

        int num1=Integer.parseInt(et_num1.getText().toString());
        int num2=Integer.parseInt(et_num2.getText().toString());
        int result=num1-num2;

        tv_result.setText(Integer.toString(result));
    }


}
